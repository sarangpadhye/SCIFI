#include <stdio.h>

void lower1(double *L,int *lda,int *m,int *n,double *u,int *errflag);
