#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "BLAS1.h"
#include <mkl.h>


void lower1(double *L,int *lda,int *m,int *n,double *u,int *errorflag)
{
	int i,j,k,dummyk,z=1,rows;
	double inter_value;
	
	rows = *m;
	for(k =0;k<rows;k++)
	{
		dummyk = k;
		inter_value = ddot(&dummyk,L,m,u,&z);
		u[k] = u[k] - inter_value;
		u[k] = u[k]/L[k*rows+k]; 
		
	}

}		
