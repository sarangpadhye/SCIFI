#include <mkl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "BLAS1.h"
#include <math.h>
#include "elapsedtime.h"
//#include "BLAS2.h"

#define MAX 1024

int getindex(int,int,int);
void lower2(double *L,int *lda,int *m,int *n,double *u,int *errflag);

void main()
{
	
	FILE *fp1,*fp2;
	double *L,*u;
	double time1_blas1,time2_blas1,time_elapsed_blas1,gflops_blas1;
	int nlower,nupper,i,j,value,errflag,nstride;
	
	fp1 = fopen("sizes.txt","r");
 	fp2 = fopen("results","w");	
	fscanf(fp1,"%d %d %d",&nlower,&nupper,&nstride);	
	L[nupper];

	//Start accepting L as a single dimentional array

	int rows = nlower;
	
	//Blas 1 operation

	printf("\nThis is Blas operation 1\n");
//	fprintf(fp2,"version\t \t n\t \t Time\t \t Gflops\n");
	
	time1_blas1 = elapsedtime(); 
	while(nlower<=nupper)
	{
		
		
		int lda;
		//Blas1 operation
		//time1_blas1 = elapsedtime();
		rows = nlower;
		nlower = nlower + nstride;

		L = (double*) malloc(rows*rows*sizeof(double));
                u = (double*) malloc(rows*sizeof(double));
		for(i=0;i<rows;++i)
		{
			for(j=0;j<rows;++j)
			{
				if(j>i)
				L[getindex(i,j,rows)] = 0;
				else
				L[getindex(i,j,rows)] = ((2*((double)rand()/(double)RAND_MAX))-1);
			}
		}				
		for(i=0;i<rows;i++)
		{
			u[i] = ((2*((double)rand()/(double)RAND_MAX))-1);
 
		}

		time1_blas1 = elapsedtime();
		lower1(L,&lda,&rows,&rows,u,&errflag);
		time2_blas1 = elapsedtime();
		time_elapsed_blas1 = time2_blas1 - time1_blas1;
		gflops_blas1 = (1.0e-9*rows*rows)/time_elapsed_blas1;			
		
		fprintf(fp2,"1 %d \t \t %.16e \t %.16e \n",rows,time_elapsed_blas1,gflops_blas1); 

		printf("%d\n",rows);
		//Blas2 operation
		
		lda = rows;
		double time1_blas2 = elapsedtime();
		//lower2(L,&lda,&rows,&rows,u,&errflag);
		double time2_blas2 = elapsedtime();
		double time_elapsed_blas2 = time2_blas2 - time1_blas2;
		double gflops_blas2 = (1.0e-9*rows*rows)/time_elapsed_blas2;					
		//fprintf(fp2,"2 %d \t \t %.16e \t %.16e \n",rows,time_elapsed_blas2,gflops_blas2); 
				

		free(L);
		free(u);
	}
	
	
	
}

		
int getindex(int row,int col,int NCOLS)
{
			
	return col*NCOLS+row;
}

void lower2(double *L,int *lda,int *m,int *n,double *u,int *errflag)
{
	char ul = 'L';
	char tr = 'N';
	char dg = 'N';
	char inx = 1;
	
	dtrsv(&ul,&tr,&dg,n,L,lda,u,&inx);
}


