double elapsedtime(void);
